import ASUS.GPIO as GPIO
import unittest   
import time     
# to use Raspberry Pi board pin numbers
GPIO.setmode(GPIO.RK)

# set up GPIO output channel, we set GPIO4 (Pin 7) to OUTPUT


GPIO.setup(187, GPIO.IN, pull_up_down=GPIO.PUD_UP)








#GPIO.setup(8, GPIO.OUT)
#GPIO.setup(1, GPIO.OUT)
#GPIO.setup(9, GPIO.OUT)
#GPIO.setup(8, GPIO.IN)
#GPIO.input(8)

#GPIO.output(9,GPIO.HIGH)
#GPIO.input(8)
#GPIO.output(9,GPIO.LOW)
#GPIO.input(8)
#GPIO.output(9,GPIO.HIGH)
#GPIO.input(8)
#GPIO.output(9,GPIO.LOW)
#GPIO.input(8)


